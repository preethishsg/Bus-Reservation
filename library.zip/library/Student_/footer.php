<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
	footer
	{
		height: 200px;
		width: 100%;
		background-color: black;
	}
		.fa
		{
			margin: 0px 5px;
			padding: 5px;
			font-size: 20px;
			width: 20px;
			height: 20px;
			text-align: center;
			text-decoration: none;
			border-radius: 50%;
		}
		.fa:hover
		{
			opacity: .7;
		}
		.fa-facebook
		{
			background: #3B5998;
			color: white;
		}
		.fa-twitter
		{
			background: #55ACEE;
			color: white;
		}
		.fa-google
		{
			background: #dd4b39;
			color: white;
		}
		.fa-instagram
		{
			background: #125688;
			color: white;
		}
		.fa-yahoo
		{
			background: #400297;
			color: white;
		}
	</style>

</head>
<body>
<footer style="background-color: black; ">
	<br>
	<h3 style="color:white;text-align: center;">Contact us through social media</h3><br>

	<div style="margin:0px 670px;">

	<a href="https://www.facebook.com/login/" class="fa fa-facebook"></a>
		<a href="https://twitter.com/i/flow/login" class="fa fa-twitter"></a>
		<a href="https://mail.google.com/login/" class="fa fa-google"></a>
		<a href="https://www.instagram.com/accounts/login/" class="fa fa-instagram"></a>
	</div>

	<br>
	<p style="color:white;text-align: center;">
		<br>
		Email:&nbsp Online.library@gmail.com <br><br>
		Mobile:&nbsp &nbsp +917000584396
	</p>
</footer>
</body>
</html>